from django.contrib import admin
from .models import Bpost,Comments
# Register your models here.

admin.site.register(Bpost)
admin.site.register(Comments)
