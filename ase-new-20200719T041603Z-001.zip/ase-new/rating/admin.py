from django.contrib import admin
from .models import Rate, Leaderboard, Report

admin.site.register(Rate)
admin.site.register(Leaderboard)
admin.site.register(Report)
