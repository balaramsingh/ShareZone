from django.contrib import admin
from .models import Notification,SharedItemsList

admin.site.register(Notification)
admin.site.register(SharedItemsList)
