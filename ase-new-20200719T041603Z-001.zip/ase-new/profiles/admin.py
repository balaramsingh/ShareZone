from django.contrib import admin
from .models import Profiles, Backgroundimage

# Register your models here.
admin.site.register(Profiles)
admin.site.register(Backgroundimage)