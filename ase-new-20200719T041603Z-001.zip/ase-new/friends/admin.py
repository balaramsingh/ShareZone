from django.contrib import admin
from .models import Friends

admin.site.register(Friends)
