from django.contrib import admin
from .models import Itemlist
# Register your models here.
admin.site.register(Itemlist)